OOVIE Cosmos DB logical backup

SENSITIVE: contains all readable live application records, including user password hashes and private CRM/chat data. Keep the archive private; it is compressed, not encrypted.
Read through the existing application's private Cosmos connection without changing source records, credentials, configuration, or network access.
Scope: every enumerated NoSQL database/container, documents, container definitions (partition keys/indexing/unique keys/TTL), stored procedures, triggers, UDFs, conflicts, and Azure account/SQL RBAC metadata. See manifest warnings for unavailable legacy SQL access metadata.
This is an online logical export over a recorded interval, not an atomic point-in-time snapshot. A second source read checks each container for observed changes. Hash equality is evidence of stability, not a global transaction guarantee.
Azure account keys, Key Vault secret values, resource tokens, external blob contents, search indexes, and historical/deleted/TTL-expired documents are not included. Infrastructure metadata is descriptive, not a complete Azure resource deployment backup.
Original Cosmos system fields are retained for evidence. Remove _rid, _self, _etag, _attachments, and _ts from import write payloads; Cosmos regenerates them. Preserve document IDs and partition-key values.
A restore must account for elapsed TTL so it does not revive expired records. Authentication challenges and queued external side effects must not be blindly replayed. Disable workers and external channels until an authorized recovery review is complete.
Do not import directly over a live database. Verify into an isolated database first, retain a pre-restore copy, and require explicit authorization for production replacement.
manifest.json lists counts, source consistency checks, and SHA-256 for each file. The adjacent .sha256 file covers the complete tar.gz archive.
